Superseded by the approved Taylor hub / truck last mile / no mine spur decision. These maps and connector are previous proposals, not current infrastructure.
