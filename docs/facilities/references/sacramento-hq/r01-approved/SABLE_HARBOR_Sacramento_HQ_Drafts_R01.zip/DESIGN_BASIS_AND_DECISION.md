# Sacramento campus — coordinated draft R01

The owner approved Sacramento as the primary operating base and all discussed Sacramento functions on one campus on September 11, 2026. This accepts the common-campus and co-sited Education direction (the recovered D-01 and Education co-siting component of D-02). It does not approve the previous square-footage/desk/room estimates or this drawing style. This is a review package; no repository push has occurred.

The scope is corporate, Foundry Field, Atlas Meridian, Advisory, J2 and Education/residence. Established Fort, Bedford, Wyoming industrial sites, field hosts and professional colocation retain their separate locations. This interpretation follows the user's express Sacramento HQ deliverable and existing accepted geography.

## Source basis

Current GitHub main was checked at `2b52933132e028bf5d9c9a8c151bb45cb0f19597`. See campus_model.json for exact source paths, SHA-256 hashes, populations and all geometry. Source workforce values are conditional forecast inputs, not a verified current payroll. No unsupported department headcounts are invented. The draft uses the source 284 corporate/product/Advisory population and 180 J2 scenario occupants; the latter includes Education. 237 J2 billets are separately established canon. The remaining Core populations and industrial staffing stay at their existing operating sites.

## One campus, ten coordinated floors

| Floor | Gross sq ft | Fitted workstations | Residential rooms | Program | Drawing status |
|---|---:|---:|---:|---|---|
| A-L01 | 23,328 | 32 | 0 | Advisory matters; client arrival; campus commons; visiting workplaces | PROGRAM_ONLY |
| A-L02 | 23,328 | 112 | 0 | Dedicated product organizations; shared project rooms | DRAFT_DRAWN |
| A-L03 | 23,328 | 56 | 0 | Corporate offices, ESS and separately secured Audit; officer seats do not establish ESS reporting | PROGRAM_ONLY |
| B-L01 | 22,464 | 62 | 0 | Contact collection; JAG return; controlled visitor intake | DRAFT_DRAWN |
| B-L02 | 22,464 | 68 | 0 | Judgment, Orientation and institutional headquarters | PROGRAM_ONLY |
| C-L01 | 15,120 | 4 | 0 | Teaching, convening, reception and shared campus kitchen/dining | DRAFT_DRAWN |
| C-L02 | 15,120 | 28 | 0 | Faculty, case design, professional and executive simulations | PROGRAM_ONLY |
| D-L01 | 10,080 | 0 | 20 | Residential cohort and visiting-faculty accommodation | PROGRAM_ONLY |
| D-L02 | 10,080 | 0 | 20 | Residential cohort and visiting-faculty accommodation | PROGRAM_ONLY |
| D-L03 | 10,080 | 0 | 20 | Residential cohort and visiting-faculty accommodation | PROGRAM_ONLY |

Total: 175,392 GSF; 362 fitted staff workplaces; 60 bedrooms. The recovered gross envelope was 173,750 GSF. The 1,642 GSF increase (0.95%) regularizes floorplates. Net usable area is not yet validated; wall/shaft and structural thicknesses must be measured in the detailed model rather than applying a blanket efficiency as fact. Floor boundary dimensions are planning dimensions.

Building A is 216 × 108 ft, three floors. B is 216 × 104 ft, two floors. C is 168 × 90 ft, two floors. D is 168 × 60 ft, three floors. Footprints on the campus map match the floor drawings. Repeated lift, stair and service shafts are reserved for all levels. Remaining seven floor drawings are intentionally held for style approval; their program reservations are already coordinated here.

## Population and use discipline

Foundry Field 160 modeled occupants / 80 desks; Atlas 36 / 32; Advisory 32 / 20; ESS 48 / 40; Audit 8 / 8. Twenty shared/visiting allowances are distributed between A-L01 and A-L03. Exact executive/support person-to-position reconciliation must be completed before A-L03 is finalized; the 8 leadership/visiting places neither assert eight new hires nor place executives under ESS authority.

J2 B contains 130 desks: Contact 48; JAG 12; Judgment 30; Orientation 16; HQ 24 (2 reception + 22 above). Education's 32 desks are in C. These are proposed physical allocations, not actual occupied J2 arm populations. Source authorization stays Contact 78, Judgment 42, Orientation 24, JAG 30, HQ 28, Education 35. Contact's 48 desks include its two office desks, so named leaders are not double counted. JAG touchdown desks do not change the six five-person teams.

C-L01 contains 120 hall seats, 48 classroom seats and 80 dining seats. Those are functional room capacities, not added employees. The old 120-day-learner planning cap remains an operational booking limit; hall/classroom peaks cannot be added to it as separate populations. Two 24-person residential cohorts plus 12 faculty/visitor rooms use D's 60 bedrooms. C-L02 case and simulation spaces are reserved, not drawn yet.

One production kitchen in C serves Education and the corporate commons. Each dining commons has 80 seats (160 total), with service turns and catered event arrangements to be sized against the attendance scenario. No production data center is inserted into the office campus; local IT rooms support buildings only.

## What these drafts establish

A common north orientation, consistent line weights, room names tied to functions, readable workstation symbols, physical dimensions, shared circulation, separate access regimes and a coordinated floor schedule. This is an architectural concept study, not a certified building design or evidence of a selected property. The campus uses a fictional 840 × 600 ft (11.57-acre) study rectangle. Parking bay counts precede accessible-bay conversion and do not assert transport sufficiency. Civil, accessibility, fire/life-safety, utilities, structural and property conditions are future design gates.

## Remaining before the complete drawing set

Approve or revise this drawing style; reconcile precise departmental staffing/attendance and executive offices; develop detailed upper-floor and residential room schedules; resolve core access, service routes, door/fixture clearances and accessible layouts; size dining, parking and event peaks together; and record the approved direction and final generated sources in the repository. The final repo package should include geometry, generator, room/workstation schedules, validation, source lineage, one image per floor and the campus master plan.
