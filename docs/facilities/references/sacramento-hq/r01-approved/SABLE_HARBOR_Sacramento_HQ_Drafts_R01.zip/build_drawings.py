"""Sacramento HQ coordinated concept drawings. Geometry in feet; no raster synthesis."""
from pathlib import Path
import json, math, hashlib, textwrap, zipfile, io, os
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon, Arc
from matplotlib.lines import Line2D

HERE=Path(__file__).resolve().parent
OUT=HERE/'drawings'; OUT.mkdir(exist_ok=True)
REPO=Path('/workspace/scratch/d96093f0ceb0/SABLEHARBOR-estate')
BASE='2b52933132e028bf5d9c9a8c151bb45cb0f19597'
COL={'paper':'#F7F6F1','white':'#FFFFFF','ink':'#223740','muted':'#687B80','line':'#A3B0AF',
     'blue':'#3F7088','bluefill':'#E3EDF0','sage':'#729085','sagefill':'#E5ECE5',
     'gold':'#A48A54','goldfill':'#F0EADD','grey':'#E7E9E5','paving':'#DDDCD5','road':'#CBCDC8'}
plt.rcParams.update({'font.family':'DejaVu Sans','svg.fonttype':'none'})
FONT='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
ALL_ROOMS=[]; SYMBOL_COUNTS={}; SHEETS=[]

def rect(ax,x,y,w,h,fc='none',ec=None,lw=1,z=2,**kw):
    p=Rectangle((x,y),w,h,facecolor=fc,edgecolor=ec or COL['ink'],linewidth=lw,zorder=z,**kw);ax.add_patch(p);return p
def line(ax,x1,y1,x2,y2,c=None,lw=1,z=5,**kw):
    ax.plot([x1,x2],[y1,y2],color=c or COL['ink'],lw=lw,zorder=z,**kw)
def txt(ax,x,y,s,size=16,color=None,weight='normal',ha='left',va='top',**kw):
    return ax.text(x,y,s,fontsize=size*.72,color=color or COL['ink'],fontweight=weight,ha=ha,va=va,zorder=20,**kw)
def para(ax,x,y,s,width=41,size=16,leading=25,color=None):
    for row in textwrap.wrap(s,width=width):
        txt(ax,x,y,row,size,color);y+=leading
    return y
def title_sheet(number,title,subtitle,kind):
    fig,ax=plt.subplots(figsize=(18,12.8),dpi=180)
    fig.patch.set_facecolor(COL['paper']);ax.set_facecolor(COL['paper']);ax.set_xlim(0,1800);ax.set_ylim(1280,0);ax.set_aspect('equal');ax.axis('off');fig.subplots_adjust(0,0,1,1)
    txt(ax,60,43,'S A B L E   H A R B O R',22,weight='bold')
    txt(ax,1740,45,'SACRAMENTO  /  INSTITUTIONAL CAMPUS',15,ha='right')
    line(ax,60,83,1740,83,lw=1.3)
    txt(ax,60,112,title,34,weight='bold')
    txt(ax,60,161,subtitle,17,color=COL['muted'])
    rect(ax,1470,113,270,34,fc=COL['ink'],ec=COL['ink'])
    txt(ax,1605,130,'CONCEPT REVIEW  /  R01',13,color='white',ha='center',va='center',weight='bold')
    line(ax,60,1192,1740,1192,lw=1.1)
    txt(ax,60,1215,'COORDINATED DESIGN STUDY  •  11 SEPTEMBER 2026',13,color=COL['muted'])
    txt(ax,60,1240,'Concept geometry; parcel, engineering and code review remain open. Areas and desks are design proposals.',12,color=COL['muted'])
    txt(ax,1740,1213,number,25,ha='right',weight='bold')
    txt(ax,1740,1250,kind,12,ha='right',color=COL['muted'])
    return fig,ax
def save(fig,code):
    png=OUT/f'{code}.png';svg=OUT/f'{code}.svg'
    for target,fmt in [(png,'png'),(svg,'svg')]:
        buf=io.BytesIO();fig.savefig(buf,format=fmt,dpi=180,facecolor=COL['paper']);target.write_bytes(buf.getvalue())
    plt.close(fig);SHEETS.append({'code':code,'png':str(png),'svg':str(svg)})
def sidebar_title(ax,title,y=240):
    line(ax,1380,y-20,1740,y-20,c=COL['line']);txt(ax,1380,y,title,17,weight='bold');return y+41
def sidebar_stat(ax,y,value,label):
    txt(ax,1380,y,value,34,weight='bold');txt(ax,1380,y+43,label,13,color=COL['muted']);return y+82
def note(ax,n,x,y,title,body,width=47):
    txt(ax,x,y,f'{n:02d}',17,color=COL['blue'],weight='bold');txt(ax,x+40,y,title,16,weight='bold')
    return para(ax,x+40,y+26,body,width,14,22,COL['muted'])
def north(ax,x,y):
    txt(ax,x,y-18,'N',15,weight='bold',ha='center')
    ax.add_patch(Polygon([(x,y+7),(x-8,y+34),(x,y+27),(x+8,y+34)],facecolor=COL['ink'],zorder=9))
def scale_bar(ax,x,y,s,length=40):
    for i in range(4):rect(ax,x+i*length*s/4,y,length*s/4,7,fc=COL['ink'] if i%2==0 else COL['paper'],lw=.7)
    for i,v in enumerate([0,length/2,length]):txt(ax,x+i*length*s/2,y+16,str(int(v)),11,ha='center')
    txt(ax,x+length*s+16,y+1,'FEET',11,color=COL['muted'])

class Floor:
    def __init__(self,ax,code,w,h,x=74,y=320,s=5.6):
        self.ax=ax;self.code=code;self.w=w;self.h=h;self.x=x;self.y=y;self.s=s;self.rooms=[];self.doors=[];self.desks=0;self.learning=0;self.dining=0
    def xy(self,x,y):return self.x+x*self.s,self.y+y*self.s
    def box(self,x,y,w,h,**kw):return rect(self.ax,*self.xy(x,y),w*self.s,h*self.s,**kw)
    def ln(self,x,y,x2,y2,**kw):line(self.ax,*self.xy(x,y),*self.xy(x2,y2),**kw)
    def text(self,x,y,t,size=12,**kw):txt(self.ax,*self.xy(x,y),t,size,**kw)
    def room(self,id,x,y,w,h,name,sub='',fill='white',label='top',small=False):
        r={'floor':self.code,'id':id,'x':x,'y':y,'width':w,'depth':h,'name':name,'detail':sub,'area_sf':w*h}
        self.rooms.append(r);ALL_ROOMS.append(r)
        self.box(x,y,w,h,fc=COL.get(fill,fill),ec=COL['ink'],lw=1.1)
        if name:
            if label=='top':
                self.text(x+w/2,y+3,name,11 if small else 15,ha='center',weight='bold')
                if sub:self.text(x+w/2,y+7.4,sub,10 if small else 12,ha='center',color=COL['muted'])
            else:
                self.text(x+w/2,y+h/2-2,name,11 if small else 14,ha='center',weight='bold')
                if sub:self.text(x+w/2,y+h/2+3,sub,10 if small else 12,ha='center',color=COL['muted'])
        return r
    def opening(self,x,y,width,side='h'):
        self.doors.append({'x':x,'y':y,'side':side,'width':width,'type':'open_passage'})
        if side=='h':self.ln(x-width/2,y,x+width/2,y,c=COL['grey'],lw=3.8,z=9)
        else:self.ln(x,y-width/2,x,y+width/2,c=COL['grey'],lw=3.8,z=9)
    def door(self,x,y,side='h',width=3.5,swing=1):
        self.doors.append({'x':x,'y':y,'side':side,'width':width,'type':'door'})
        # Door centre on wall. Erase wall only across opening, then draw leaf and arc.
        ax=self.ax;s=self.s;a,b=self.xy(x,y);d=width*s
        if side=='h' and width>4:
            line(ax,a-d/2,b,a+d/2,b,c=COL['paper'],lw=3.4,z=7)
            for xx,lo,hi in [(a-d/2,0,90),(a+d/2,90,180)]:
                line(ax,xx,b,xx,b+swing*d/2,lw=.8,z=8)
                ax.add_patch(Arc((xx,b),d,d,theta1=lo if swing>0 else 360-hi,theta2=hi if swing>0 else 360-lo,ec=COL['muted'],lw=.6,zorder=8))
            return
        if side=='h':
            line(ax,a-d/2,b,a+d/2,b,c=COL['paper'],lw=3.4,z=7)
            line(ax,a-d/2,b,a-d/2,b+swing*d,lw=.8,z=8)
            ax.add_patch(Arc((a-d/2,b),2*d,2*d,theta1=0 if swing>0 else 270,theta2=90 if swing>0 else 360,ec=COL['muted'],lw=.6,zorder=8))
        else:
            line(ax,a,b-d/2,a,b+d/2,c=COL['paper'],lw=3.4,z=7)
            line(ax,a,b-d/2,a+swing*d,b-d/2,lw=.8,z=8)
            ax.add_patch(Arc((a,b-d/2),2*d,2*d,theta1=0 if swing>0 else 90,theta2=90 if swing>0 else 180,ec=COL['muted'],lw=.6,zorder=8))
    def chair(self,x,y,rotation=0):
        self.box(x-.95,y-.9,1.9,1.8,fc=COL['paper'],ec=COL['muted'],lw=.5)
    def bench(self,x,y,count=4):
        # 5 x 2.5 ft per work surface; chairs have a distinct symbol from meeting seats.
        if count==4:
            self.box(x,y,10,5,fc='white',ec=COL['muted'],lw=.7);self.ln(x+5,y,x+5,y+5,c=COL['line'],lw=.5);self.ln(x,y+2.5,x+10,y+2.5,c=COL['line'],lw=.5)
            for dx in [2.5,7.5]:
                self.chair(x+dx,y-1.7);self.chair(x+dx,y+6.7)
                self.box(x+dx-1,y+1.4,2,.15,fc=COL['muted'],ec=COL['muted'],lw=.2)
                self.box(x+dx-1,y+3.4,2,.15,fc=COL['muted'],ec=COL['muted'],lw=.2)
        elif count==2:
            self.box(x,y,10,2.5,fc='white',ec=COL['muted'],lw=.7);self.ln(x+5,y,x+5,y+2.5,c=COL['line'],lw=.5)
            for dx in [2.5,7.5]:self.chair(x+dx,y+4.2)
        elif count==1:
            self.box(x,y,5,2.5,fc='white',ec=COL['muted'],lw=.7);self.chair(x+2.5,y+4.2)
        self.desks+=count
    def benches(self,x,y,cols,rows,dx,dy,counts=None):
        counts=counts or [4]*(cols*rows)
        for i,count in enumerate(counts):self.bench(x+(i%cols)*dx,y+(i//cols)*dy,count)
    def meeting(self,x,y,seats=8,w=10,h=4):
        self.box(x-w/2,y-h/2,w,h,fc=COL['paper'],ec=COL['muted'],lw=.65)
        n=(seats-2)//2
        for j in range(n):
            a=x-w/2+(j+1)*w/(n+1);self.chair(a,y-h/2-1.6);self.chair(a,y+h/2+1.6)
        self.chair(x-w/2-1.6,y);self.chair(x+w/2+1.6,y)
    def stair(self,x,y,w=18,h=24,label='ST'):
        self.room(label+str(x),x,y,w,h,'',fill='grey')
        for i in range(9):self.ln(x+2,y+3+i*1.65,x+w-2,y+3+i*1.65,c=COL['muted'],lw=.5)
        self.text(x+w/2,y+h-4,label,11,ha='center',weight='bold')
        self.ln(x+w/2,y+17,x+w/2,y+4,c=COL['ink'],lw=.6)
    def shell(self,grids=27):
        self.box(0,0,self.w,self.h,fc='none',ec=COL['ink'],lw=2.5,z=7)
        # Consistent dimension grid and window traces; exterior doors added later.
        for x in range(0,int(self.w)+1,grids):
            self.ln(x,-7,x,-1,c=COL['line'],lw=.55)
            self.text(x,-13,str(x),10,color=COL['muted'],ha='center')
        self.ln(0,-7,self.w,-7,c=COL['muted'],lw=.65)
        txt(self.ax,self.x+self.w*self.s/2,self.y-116,f'{self.w}′  OVERALL',13,ha='center',weight='bold')
        self.ln(-6,0,-6,self.h,c=COL['muted'],lw=.65)
        self.text(-9,self.h/2,f'{self.h}′',12,rotation=90,ha='center')
        for x in range(24,int(self.w)-18,18):
            self.ln(x,0,x+10,0,c=COL['blue'],lw=2.8,z=8)
            self.ln(x,self.h,x+10,self.h,c=COL['blue'],lw=2.8,z=8)
        north(self.ax,self.x+self.w*self.s+36,self.y-48)
    def validate(self):
        for r in self.rooms:
            assert r['x']>=0 and r['y']>=0 and r['x']+r['width']<=self.w and r['y']+r['depth']<=self.h,r
        for i,a in enumerate(self.rooms):
            for b in self.rooms[i+1:]:
                ox=min(a['x']+a['width'],b['x']+b['width'])-max(a['x'],b['x'])
                oy=min(a['y']+a['depth'],b['y']+b['depth'])-max(a['y'],b['y'])
                assert not (ox>.001 and oy>.001),(a['id'],b['id'])
        def containing(x,y):
            for r in self.rooms:
                if r['x'] < x < r['x']+r['width'] and r['y'] < y < r['y']+r['depth']:return r['id']
            return 'OUTSIDE'
        graph={r['id']:set() for r in self.rooms};graph['OUTSIDE']=set()
        for d in self.doors:
            x,y=d['x'],d['y'];dx,dy=(0,.05) if d['side']=='h' else (.05,0)
            a,b=containing(x-dx,y-dy),containing(x+dx,y+dy)
            if a!=b:graph[a].add(b);graph[b].add(a)
        seen={'spine'};pending=['spine']
        while pending:
            for nxt in graph[pending.pop()]:
                if nxt not in seen:seen.add(nxt);pending.append(nxt)
        missing=[r['id'] for r in self.rooms if r['id'] not in seen and 'riser' not in r['id'].lower()]
        assert not missing,(self.code,'rooms without a connected door/path',missing)
        SYMBOL_COUNTS[self.code]={'workstation_symbols':self.desks,'learning_seat_symbols':self.learning,'dining_seat_symbols':self.dining,'rooms':len(self.rooms),'gross_floor_sf':self.w*self.h,'all_non_riser_rooms_reachable':'PASS','access_openings':self.doors}

def corporate():
    fig,ax=title_sheet('A-102','CORPORATE  /  LEVEL 02','Product engineering and deployment work  •  One floor shown  •  North is up','A  /  PRODUCT FLOOR')
    f=Floor(ax,'A-L02',216,108)
    f.room('spine',18,48,180,12,'',fill='grey')
    f.room('cross-n',102,0,12,48,'',fill='grey');f.room('cross-s',102,60,12,48,'',fill='grey')
    f.room('A2-01',18,0,72,48,'FOUNDRY FIELD','WEST STUDIO  /  40 WORKSTATIONS',fill='bluefill')
    f.room('A2-02',18,60,72,48,'FOUNDRY FIELD','SOUTH STUDIO  /  40 WORKSTATIONS',fill='bluefill')
    f.room('A2-03',126,0,72,48,'ATLAS MERIDIAN','PRODUCT DEVELOPMENT  /  32 WORKSTATIONS',fill='sagefill')
    f.benches(23,15,5,2,13.2,18);f.benches(23,75,5,2,13.2,18)
    f.benches(134,15,4,2,15,18)
    for x in [90,114]:
        for y in [0,24]:
            f.room(f'H-{x}-{y}',x,y,12,24,'HUDDLE','4 seats',small=True)
            f.meeting(x+6,y+16,4,w=4,h=3)
            f.door(x+12 if x==90 else x,y+13,'v',swing=-1 if x==90 else 1)
    f.room('project-access',126,60,8,48,'',fill='grey')
    f.room('project-cross',134,80,64,8,'',fill='grey')
    for x in [134,166]:
        for y in [60,88]:
            f.room(f'P-{x}-{y}',x,y,32,20,'PROJECT ROOM','8 meeting seats',fill='goldfill')
            f.meeting(x+16,y+14.5,8,w=12)
            f.door(x+6,80 if y==60 else 88,'h',swing=-1 if y==60 else 1)
    for x in [0,198]:
        for y in [0,24]:
            h=24 if y==0 else 18
            f.room(f'Q-{x}-{y}',x,y,18,h,'FOCUS' if y==0 else 'CALLS','4 seats' if y==0 else '',small=True)
            if y==0:f.meeting(x+9,y+15,4,w=5,h=3)
            else:
                for dy in [7,12]:f.box(x+4,y+dy,9,4,fc=COL['paper'],ec=COL['line'],lw=.55)
            f.door(x+18 if x==0 else x,y+11,'v',swing=-1 if x==0 else 1)
        f.stair(x,42,label='ST-1' if x==0 else 'ST-2');f.door(x+18 if x==0 else x,54,'v',swing=-1 if x==0 else 1)
        f.room(f'S-{x}',x,66,18,42,'SUPPORT','AV / print / store',fill='grey',label='center',small=True)
        f.door(x+18 if x==0 else x,84,'v',swing=-1 if x==0 else 1)
    f.room('WC1',90,60,12,24,'WC','',fill='grey',label='center',small=True)
    f.room('WC2',90,84,12,24,'WC','',fill='grey',label='center',small=True)
    f.room('lift',114,60,12,14,'LIFT','',fill='grey',label='center',small=True)
    f.room('riser',114,74,12,10,'RISER','',fill='grey',label='center',small=True)
    f.room('it',114,84,12,24,'IT / AV','',fill='grey',label='center',small=True)
    for y in [71,96]:f.door(102,y,'v',swing=-1)
    for y in [67,96]:f.door(114,y,'v',swing=1)
    for x in [54,162]:f.door(x,48,'h',swing=-1)
    f.door(54,60,'h',swing=1)
    f.text(55,54,'12′ SHARED CIRCULATION',12,ha='center',va='center',color=COL['muted'])
    f.text(163,54,'TWO SEPARATE PRODUCT ORGANIZATIONS',11,ha='center',va='center',color=COL['muted'])
    f.opening(108,48,12);f.opening(108,60,12);f.opening(130,60,8);f.opening(134,84,8,'v')
    f.shell();f.validate();assert f.desks==112
    y=sidebar_title(ax,'THIS FLOOR');y=sidebar_stat(ax,y,'112','FITTED WORKSTATIONS');y=sidebar_stat(ax,y,'23,328','GROSS SQUARE FEET')
    y=sidebar_title(ax,'STAFF ≠ DESKS',y+12)
    y=para(ax,1380,y,'Foundry Field: 160 modeled staff / 80 desks here. Atlas Meridian: 36 modeled staff / 32 desks here.',36,16,25)
    y=para(ax,1380,y+18,'Desk ratios reflect hybrid work and deployments. They do not reduce either team’s headcount.',36,16,25)
    y=sidebar_title(ax,'IN THE SAME BUILDING',y+35)
    y=para(ax,1380,y,'L01  Advisory, client reception, visiting workplaces and commons.',36,16,25)
    y=para(ax,1380,y+12,'L03  Corporate officers, ESS and an independently secured Audit suite.',36,16,25)
    y=para(ax,1380,y+20,'Stairs, lift and service shafts retain the same coordinates on all three floors.',36,15,24,COL['muted'])
    note(ax,1,76,1003,'TEAM BOUNDARIES','Shared project rooms support joint work; Atlas stays a dedicated product organization.',51)
    note(ax,2,730,1003,'CAMPUS CONNECTION','Visitors check in on L01. J2 and the teaching/residential precinct have their own entrances.',51)
    scale_bar(ax,90,1139,f.s,40);txt(ax,560,1134,'Blue: Foundry Field   /   Sage: Atlas Meridian   /   Sand: shared project rooms',14,color=COL['muted'])
    save(fig,'02_Corporate_L02_Product_Draft')

def j2():
    fig,ax=title_sheet('B-101','J2  /  LEVEL 01','Contact, field-team return and reception  •  One floor shown  •  North is up','B  /  CONTACT + JAG')
    f=Floor(ax,'B-L01',216,104,y=330)
    f.room('spine',18,46,180,12,'',fill='grey');f.room('crossN',102,0,12,46,'',fill='grey');f.room('crossS',102,58,12,24,'',fill='grey')
    f.room('contactW',18,0,72,46,'CONTACT','WEST STUDIO  /  22 WORKSTATIONS',fill='bluefill')
    f.room('contactE',126,0,72,46,'CONTACT','EAST STUDIO  /  24 WORKSTATIONS',fill='bluefill')
    f.benches(28,15,3,2,21,18,counts=[4,4,4,4,4,2]);f.benches(136,15,3,2,21,18)
    f.room('mara',0,0,18,20,'HEAD','Mara Hammer',fill='bluefill',small=True);f.bench(6,11,1)
    f.room('deputy',0,20,18,20,'DEPUTY','Contact',fill='bluefill',small=True);f.bench(6,31,1)
    for y in [12,32]:f.door(18,y,'v',swing=-1)
    for x in [90,114]:
        for y in [0,23]:
            f.room(f'work-{x}-{y}',x,y,12,23,'CASE','4 seats',small=True);f.meeting(x+6,y+15,4,w=4,h=3)
            f.door(x+12 if x==90 else x,y+12,'v',swing=-1 if x==90 else 1)
    f.room('JAG',18,58,72,46,'JUNCTION ADVISORY GROUP','12 TOUCHDOWN DESKS  /  SIX RETURNING TEAMS',fill='sagefill')
    f.benches(28,73,3,2,21,17,counts=[2]*6)
    for i in range(6):f.text(33+(i%3)*21,79+(i//3)*17,f'TEAM {i+1}',9,ha='center',color=COL['muted'])
    f.room('WC',90,58,12,24,'WC','',fill='grey',label='center',small=True)
    f.room('lift',114,58,12,14,'LIFT','',fill='grey',label='center',small=True)
    f.room('riser',114,72,12,10,'RISER','',fill='grey',label='center',small=True)
    f.room('reception',90,82,36,22,'RECEPTION','2 HQ support desks',fill='goldfill')
    f.bench(94,94,2)
    f.room('visCorr',126,82,72,8,'',fill='goldfill')
    f.room('interview1',126,58,36,24,'INTERVIEW 01','6 meeting seats',fill='goldfill');f.meeting(144,73,6,w=9)
    f.room('interview2',162,58,36,24,'INTERVIEW 02','6 meeting seats',fill='goldfill');f.meeting(180,73,6,w=9)
    for x in [144,180]:f.door(x,82,'h',swing=-1)
    f.room('waiting',126,90,72,14,'VISITOR WAITING','Reception-controlled access',fill='goldfill',label='center')
    f.door(126,86,'v',swing=1);f.door(144,90,'h',swing=1)
    f.door(108,82,'h',width=4,swing=-1)
    f.text(108,78,'ACCESS',9,ha='center',weight='bold',color=COL['blue'])
    f.door(102,68,'v',swing=-1);f.door(114,65,'v',swing=1)
    for x in [0,198]:
        f.stair(x,40,label='ST-1' if x==0 else 'ST-2');f.door(x+18 if x==0 else x,52,'v',swing=-1 if x==0 else 1)
        f.room(f'support-{x}',x,64,18,40,'FIELD' if x==0 else 'SERVICES','lockers / kit' if x==0 else 'MEP / store',fill='grey',label='center',small=True)
        if x==0:f.door(18,76,'v',swing=-1)
        else:f.door(216,76,'v',swing=1)
    f.room('methods',198,0,18,20,'METHODS','4 seats',small=True);f.meeting(207,14,4,w=5,h=3)
    f.room('equipment',198,20,18,20,'KIT','prep / store',small=True,label='center',fill='grey')
    for y in [12,32]:f.door(198,y,'v',swing=1)
    for x in [54,162]:f.door(x,46,'h',swing=-1)
    f.door(54,58,'h',swing=1)
    f.text(56,52,'STAFF CIRCULATION',12,ha='center',va='center',color=COL['muted'])
    f.text(164,52,'CONTACT ↔ JUDGMENT / ORIENTATION ABOVE',11,ha='center',va='center',color=COL['muted'])
    f.opening(108,46,12);f.opening(108,58,12)
    f.door(0,52,'v',width=4,swing=-1);f.door(216,52,'v',width=4,swing=1)
    f.shell(grids=27);f.door(108,104,'h',width=6,swing=-1)
    f.text(108,110,'CAMPUS ENTRY',12,ha='center',weight='bold')
    f.validate();assert f.desks==62
    y=sidebar_title(ax,'THIS FLOOR');y=sidebar_stat(ax,y,'62','FITTED WORKSTATIONS');y=sidebar_stat(ax,y,'22,464','GROSS SQUARE FEET')
    y=sidebar_title(ax,'WORKPLACE ALLOCATION',y+15)
    y=para(ax,1380,y,'48 Contact workplaces, including Head and Deputy; 12 JAG touchdown desks; 2 HQ reception/support desks.',36,16,25)
    y=para(ax,1380,y+17,'JAG remains six five-person teams. Two touchdown desks per team are not a reduction to two-person teams.',36,16,25)
    y=sidebar_title(ax,'UPSTAIRS  /  LEVEL 02',y+33)
    y=para(ax,1380,y,'30 Judgment + 16 Orientation + 22 J2 HQ desks. Total building fit-out: 130 workplaces.',36,16,25)
    y=para(ax,1380,y+18,'237 authorized J2 billets include Education’s 35 in C. Actual occupied staff by arm are not recorded.',36,15,24,COL['muted'])
    note(ax,1,76,1003,'VISITOR PATH','Reception and interview rooms sit before the staff boundary. Visitors do not cross a Contact studio.',51)
    note(ax,2,730,1003,'INSTITUTIONAL SEPARATION','J2 has its own building and reception. Education is nearby; ESS and Internal Audit remain separate.',51)
    scale_bar(ax,90,1139,f.s,40);txt(ax,560,1134,'Blue: Contact   /   Sage: JAG   /   Sand: reception and visitor rooms',14,color=COL['muted'])
    save(fig,'03_J2_L01_Contact_JAG_Draft')

def education():
    fig,ax=title_sheet('C-101','EDUCATION  /  LEVEL 01','Teaching, convening and shared hospitality  •  One floor shown  •  North is up','C  /  LEARNING + COMMONS')
    f=Floor(ax,'C-L01',168,90,x=85,y=321,s=7.05)
    f.room('spine',0,40,168,10,'',fill='grey')
    f.room('core-access-west',16,0,8,40,'',fill='grey')
    f.room('core-access-east',152,0,8,40,'',fill='grey')
    f.room('hall',24,0,72,40,'CONVENING HALL','120 FLEXIBLE SEATS  /  FLAT FLOOR',fill='goldfill')
    f.box(28,10,56,3,fc=COL['paving'],ec=COL['line'],lw=.6)
    for row in range(10):
        for col in range(12):
            x=35+col*3.1+(5 if col>=6 else 0);y=15+row*2.25;f.chair(x,y);f.learning+=1
    # Clear centre aisle, side aisles and two independent corridor doors.
    for x in [30,83]:f.door(x,40,'h',width=5,swing=1)
    for x,code in [(96,'01'),(124,'02')]:
        f.room('class'+code,x,0,28,40,'CLASSROOM '+code,'24 LEARNERS',fill='bluefill')
        for i in range(6):
            xx=x+8+(i%2)*12; yy=15+(i//2)*9
            f.meeting(xx,yy,4,w=6,h=3);f.learning+=4
        f.door(x+14,40,'h',width=4,swing=-1)
    f.room('dining',72,50,52,40,'CAMPUS DINING  /  80 SEATS','',fill='sagefill')
    for row,cols in [(0,4),(1,4),(2,2)]:
        for col in range(cols):
            x=78.5+col*13;y=61+row*12
            f.box(x-5,y-1.5,10,3,fc=COL['paper'],ec=COL['muted'],lw=.65)
            for seat in range(4):
                f.chair(x-3.75+seat*2.5,y-3.2);f.chair(x-3.75+seat*2.5,y+3.2);f.dining+=2
    f.room('kitchen',124,50,28,40,'KITCHEN','Shared campus production',fill='grey')
    for y in [64,71,78]:f.box(127,y,20,3,fc='white',ec=COL['muted'],lw=.6)
    f.door(124,72,'v',width=4,swing=1);f.door(138,90,'h',width=5,swing=-1)
    f.room('lobby',16,50,56,40,'EDUCATION RECEPTION','4 PROGRAM / REGISTRAR DESKS',fill='goldfill')
    f.benches(21,65,2,1,13,12,counts=[2,2])
    f.box(57,59,9,3,fc=COL['paving'],ec=COL['muted'],lw=.7)
    f.box(57,66,9,3,fc=COL['paving'],ec=COL['muted'],lw=.7)
    f.door(44,50,'h',width=6,swing=-1)
    f.door(98,50,'h',width=5,swing=1)
    f.room('wcWest',0,0,16,24,'WC','',fill='grey',label='center',small=True)
    f.room('lift',0,24,16,16,'LIFT','',fill='grey',label='center',small=True)
    f.room('riser',160,0,8,40,'',fill='grey')
    f.text(164,20,'RISERS',10,ha='center',rotation=90)
    f.door(16,12,'v',swing=-1);f.door(16,32,'v',swing=-1)
    for x in [0,152]:
        f.stair(x,50,w=16,h=24,label='ST-1' if x==0 else 'ST-2');f.door(x+8,50,'h',swing=1)
        f.door(x if x==0 else x+16,62,'v',width=4,swing=-1 if x==0 else 1)
    f.room('store',0,74,16,16,'STORE','',fill='grey',label='center',small=True);f.door(16,82,'v',swing=-1)
    f.room('wcEast',152,74,16,16,'STAFF WC','',fill='grey',label='center',small=True);f.door(152,82,'v',swing=1)
    f.text(57,45,'10′ SHARED TEACHING CIRCULATION',12,ha='center',va='center',color=COL['muted'])
    f.text(124,45,'CLASSROOMS ↔ HALL',12,ha='center',va='center',color=COL['muted'])
    f.opening(20,40,8);f.opening(156,40,8)
    f.shell(grids=28);f.door(44,90,'h',width=7,swing=-1);f.text(44,96,'CAMPUS ENTRY',12,ha='center',weight='bold')
    f.text(138,96,'CATERING / SERVICE',10,ha='center',color=COL['muted'])
    f.validate();assert f.desks==4 and f.learning==168 and f.dining==80
    y=sidebar_title(ax,'THIS FLOOR');y=sidebar_stat(ax,y,'120','HALL SEATS');y=sidebar_stat(ax,y,'2 × 24','CLASSROOM SEATS');y=sidebar_stat(ax,y,'80','DINING SEATS')
    y=sidebar_title(ax,'ONE EDUCATION ARM',y+15)
    y=para(ax,1380,y,'35 authorized Education billets, already within J2. Four workplaces here + 28 upstairs = 32 fitted desks.',36,16,25)
    y=para(ax,1380,y+15,'L02 houses faculty, case design, breakout rooms and executive / board simulations.',36,16,25)
    y=sidebar_title(ax,'RESIDENTIAL COURT  /  D',y+30)
    y=para(ax,1380,y,'60 rooms in a separate quiet building on the same campus: 48 cohort rooms + 12 faculty / visitor rooms.',36,16,25)
    y=para(ax,1380,y+16,'120 day learners is the planning attendance cap. Room seats are alternative teaching configurations, not extra staff.',36,15,24,COL['muted'])
    note(ax,1,76,1030,'SHARED HOSPITALITY','One production kitchen serves C and the corporate commons; 160 dining seats across the two buildings.',50)
    note(ax,2,730,1030,'QUIET RESIDENTIAL EDGE','Residential arrivals and teaching arrivals use separate doors. The residence is a short walk across its own court.',50)
    scale_bar(ax,90,1148,f.s,28)
    save(fig,'04_Education_L01_Teaching_Draft')

BUILDINGS=[
 {'id':'A','name':'CORPORATE','x':148,'y':340,'w':216,'h':108,'floors':3,'desks':200,'color':'blue','sub':'Corporate · Foundry Field · Atlas · Advisory'},
 {'id':'B','name':'J2','x':148,'y':126,'w':216,'h':104,'floors':2,'desks':130,'color':'blue','sub':'Contact · Judgment · Orientation · JAG · HQ'},
 {'id':'C','name':'EDUCATION','x':468,'y':340,'w':168,'h':90,'floors':2,'desks':32,'color':'gold','sub':'Teaching · Faculty · Shared hospitality'},
 {'id':'D','name':'RESIDENCE','x':468,'y':134,'w':168,'h':60,'floors':3,'rooms':60,'color':'sage','sub':'Cohorts · Visiting faculty'},
]
def campus():
    fig,ax=title_sheet('MP-001','ONE CAMPUS  /  FOUR CONNECTED BUILDINGS','Sacramento primary operating base  •  Coordinated conceptual site  •  North is up','MASTER PLAN  /  R01')
    ox,oy,s=67,238,1.51
    def b(x,y,w,h,**kw):return rect(ax,ox+x*s,oy+y*s,w*s,h*s,**kw)
    def l(x,y,x2,y2,**kw):line(ax,ox+x*s,oy+y*s,ox+x2*s,oy+y2*s,**kw)
    def t(x,y,st,size=14,**kw):txt(ax,ox+x*s,oy+y*s,st,size,**kw)
    # 840 x 600 ft = 11.57 acres. Roads and parking are bounded by a fictional study envelope.
    b(0,0,840,600,fc='#EBEEE6',ec=COL['ink'],lw=1.5)
    for x,y,w,h in [(30,30,780,26),(30,544,780,26),(30,30,26,540),(784,30,26,540)]:b(x,y,w,h,fc=COL['road'],ec=COL['road'],lw=0)
    b(397,544,46,56,fc=COL['road'],ec=COL['road'],lw=0)
    # Distinct pedestrian paths link every front door and avoid service courts.
    for x,y,w,h in [(402,85,26,459),(124,266,540,20),(247,230,18,56),(543,194,18,92),(247,286,18,54),(450,286,14,188),(247,448,18,30),(503,430,18,44),(247,460,274,14)]:b(x,y,w,h,fc=COL['paving'],ec=COL['paving'],lw=0)
    b(130,236,246,24,fc='#E0E5DF',ec=COL['line'],lw=.6)
    b(463,210,180,40,fc='#E1E7DA',ec=COL['line'],lw=.6)
    b(291,293,211,34,fc='#E1E7DA',ec=COL['line'],lw=.6)
    # Service spurs terminate at building back-of-house edges, separate from the main walk.
    b(56,114,92,20,fc=COL['road'],ec=COL['road'],lw=0)
    b(636,110,148,20,fc=COL['road'],ec=COL['road'],lw=0)
    b(636,416,148,18,fc=COL['road'],ec=COL['road'],lw=0)
    b(602,430,51,23,fc=COL['paving'],ec=COL['muted'],lw=.5)
    # Vehicle access to every parking aisle; parking rows do not stand in for access roads.
    for x,y,w,h in [(56,78,100,24),(84,134,24,12),(84,434,24,86),(722,130,24,16),(56,496,728,24)]:
        b(x,y,w,h,fc=COL['road'],ec=COL['road'],lw=0)
    # Parking: two side courts, 32 stalls per bank; southern court, 44 per bank.
    parking=0
    for px,rows in [(66,32),(704,30)]:
        b(px,146,60,rows*9,fc='#DEE0DA',ec=COL['line'],lw=.5)
        for i in range(rows):
            for xx in [px,px+42]:b(xx,146+i*9,18,9,fc='none',ec='#A8AEA7',lw=.35);parking+=1
    b(168,478,396,60,fc='#DEE0DA',ec=COL['line'],lw=.5)
    for i in range(44):
        for yy in [478,520]:b(168+i*9,yy,9,18,fc='none',ec='#A8AEA7',lw=.35);parking+=1
    b(156,60,216,60,fc='#DEE0DA',ec=COL['line'],lw=.5)
    for i in range(24):
        for yy in [60,102]:b(156+i*9,yy,9,18,fc='none',ec='#A8AEA7',lw=.35);parking+=1
    # Midpoint crossing through south court replaces eight bays, providing safe walk + access study reserve.
    b(393,478,36,60,fc=COL['paving'],ec=COL['paving'],lw=0);parking-=8
    # Entry courts: drop-off and sheltered walk, connected to south loop.
    b(577,478,108,18,fc='#DDE2D9',ec=COL['line'],lw=.5)
    t(630,482,'BIKES / ACCESS',10,ha='center',weight='bold');t(630,504,'DROP-OFF LANE',10,ha='center',color=COL['muted'])
    # Trees: deterministic palette and placement, no fake parcel information.
    pts=[(x,78) for x in range(440,664,32)]+[(x,307) for x in [154,186,218,570,602,634]]+[(380,y) for y in [134,168,202,236,342,378,414]]+[(448,y) for y in [130,170,210,240,340,380,414]]
    for x,y in pts:
        ax.add_patch(Circle((ox+x*s,oy+y*s),8*s,facecolor='#D3DECE',edgecolor='#9AAF9C',lw=.5,zorder=3))
        ax.add_patch(Circle((ox+(x-2)*s,oy+(y-2)*s),4.5*s,facecolor='#DDE6D9',edgecolor='none',zorder=3))
    for d in BUILDINGS:
        x,y,w,h=d['x'],d['y'],d['w'],d['h'];c=COL[d['color']]
        b(x+3,y+4,w,h,fc='#CCD2CB',ec='none',lw=0,z=4)
        b(x,y,w,h,fc=COL['white'],ec=c,lw=2,z=5)
        b(x,y,8,h,fc=c,ec=c,lw=0,z=6)
        t(x+22,y+11,d['id'],30,color=c,weight='bold')
        t(x+w/2+7,y+h/2-11,d['name'],20,ha='center',weight='bold')
        t(x+w/2+7,y+h/2+8,f'{d["floors"]} FLOORS  /  '+(f'{d["desks"]} DESKS' if 'desks'in d else '60 ROOMS'),12,ha='center',color=COL['muted'])
        # Campus footprints exactly match all single-floor drawings.
        if d['id']=='C':ex=x+44
        else:ex=x+w/2
        ey=y+h
        ax.add_patch(Polygon([(ox+(ex-5)*s,oy+(ey+8)*s),(ox+(ex+5)*s,oy+(ey+8)*s),(ox+ex*s,oy+ey*s)],facecolor=c,zorder=9))
    t(396,306,'CENTRAL QUAD',12,ha='center',weight='bold',color=COL['sage'])
    t(553,224,'RESIDENTIAL COURT',12,ha='center',color=COL['sage'],weight='bold')
    t(253,243,'J2 RECEPTION COURT',11,ha='center',color=COL['blue'])
    t(415,578,'PRIMARY CAMPUS ARRIVAL',13,ha='center',weight='bold')
    t(759,277,'STAFF PARKING',11,rotation=90,ha='center',color=COL['muted'])
    t(136,289,'STAFF PARKING',11,rotation=90,ha='center',color=COL['muted'])
    t(261,508,'PARKING COURT',11,ha='center',color=COL['muted'])
    north(ax,ox+812*s,oy+80*s)
    # Labels use a single campus coordinate system. Connecting routes land at actual entry points.
    # C entrance offset is connected to the main east path along its south frontage.

    y=sidebar_title(ax,'CAMPUS SCHEDULE',240)
    for d in BUILDINGS:
        txt(ax,1380,y,d['id'],22,color=COL[d['color']],weight='bold');txt(ax,1420,y,d['name'],17,weight='bold')
        y=para(ax,1420,y+27,d['sub'],33,14,22,COL['muted'])+22
    y=sidebar_title(ax,'ONE COORDINATED PROGRAM',y+5)
    y=para(ax,1380,y,'A  69,984 gross sq ft\nB  44,928 gross sq ft\nC  30,240 gross sq ft\nD  30,240 gross sq ft'.replace('\n',' | '),36,15,25)
    y=para(ax,1380,y+18,'175,392 gross sq ft total. A 0.9% increase over the recovered envelope to use consistent floorplates.',36,15,24)
    y=para(ax,1380,y+16,'362 fitted staff workplaces + 60 residential rooms. Meeting, learning and dining seats are counted separately.',36,15,24)
    y=para(ax,1380,y+16,f'{parking} drawn parking bays before accessible-bay conversion. Transport demand and event overflow remain to be resolved.',36,14,22,COL['muted'])
    scale_bar(ax,88,1160,s,100)
    txt(ax,500,1165,'840′ × 600′  /  11.57-acre fictional study envelope  /  No actual parcel selected',14,color=COL['muted'])
    SYMBOL_COUNTS['campus']={'parking_bays_before_accessible_conversion':parking,'land_area_sf':840*600,'gross_building_sf':sum(d['w']*d['h']*d['floors'] for d in BUILDINGS)}
    save(fig,'01_Sacramento_Campus_Master_Draft')

def docs():
    wf=json.loads((REPO/'enterprise/business/source/policy.json').read_text())['workforce']
    floor_schedule=[
      {'id':'A-L01','gross_sf':23328,'desks':32,'allocation':{'Advisory':20,'shared/visiting':12},'purpose':'Advisory matters; client arrival; campus commons; visiting workplaces','drawing_status':'PROGRAM_ONLY'},
      {'id':'A-L02','gross_sf':23328,'desks':112,'allocation':{'Foundry Field':80,'Atlas Meridian':32},'purpose':'Dedicated product organizations; shared project rooms','drawing_status':'DRAFT_DRAWN'},
      {'id':'A-L03','gross_sf':23328,'desks':56,'allocation':{'ESS':40,'Internal Audit':8,'enterprise leadership/visiting allowance':8},'purpose':'Corporate offices, ESS and separately secured Audit; officer seats do not establish ESS reporting','drawing_status':'PROGRAM_ONLY'},
      {'id':'B-L01','gross_sf':22464,'desks':62,'allocation':{'Contact':48,'JAG':12,'J2 HQ reception':2},'purpose':'Contact collection; JAG return; controlled visitor intake','drawing_status':'DRAFT_DRAWN'},
      {'id':'B-L02','gross_sf':22464,'desks':68,'allocation':{'Judgment':30,'Orientation':16,'J2 HQ':22},'purpose':'Judgment, Orientation and institutional headquarters','drawing_status':'PROGRAM_ONLY'},
      {'id':'C-L01','gross_sf':15120,'desks':4,'allocation':{'Education program/registrar':4},'purpose':'Teaching, convening, reception and shared campus kitchen/dining','drawing_status':'DRAFT_DRAWN'},
      {'id':'C-L02','gross_sf':15120,'desks':28,'allocation':{'Education faculty/design/leadership':28},'purpose':'Faculty, case design, professional and executive simulations','drawing_status':'PROGRAM_ONLY'},
      *[{'id':f'D-L0{i}','gross_sf':10080,'desks':0,'rooms':20,'purpose':'Residential cohort and visiting-faculty accommodation','drawing_status':'PROGRAM_ONLY'} for i in [1,2,3]]
    ]
    for r in floor_schedule:
        if 'allocation'in r:assert sum(r['allocation'].values())==r['desks']
    assert sum(r['desks'] for r in floor_schedule)==362
    assert sum(r['gross_sf'] for r in floor_schedule)==175392
    refs=['docs/canon/CORPORATE_HEADQUARTERS_CLOSEOUT_2026-09-03.md','docs/governance/ENTERPRISE_SUPPORT_SERVICES_AND_INDEPENDENCE.md','docs/j2/J2_ESTABLISHMENT.md','docs/j2/J2_HEADQUARTERS.md','docs/j2/EDUCATION.md','docs/canon/J2_LEADERSHIP_APPOINTMENTS_2026-09-10.md','enterprise/business/source/policy.json','docs/organization/source/chartbook.json']
    model={'revision':'R01','state':'DRAFT_STYLE_AND_SPACE_REVIEW','source_main':BASE,'owner_decision':{'date':'2026-09-11','text':'Sacramento will be the primary operating base. Everything you mentioned will be on the same campus.','interpreted_scope':['corporate','Foundry Field','Atlas Meridian','Advisory','J2','Education including residence'],'accepted_direction':True,'repository_acceptance':'NOT_YET_PUSHED','unapproved':['style','room layouts','desk assignments','floor areas','site parcel','construction/procurement','costs']},'sources':[{'path':p,'sha256':hashlib.sha256((REPO/p).read_bytes()).hexdigest()} for p in refs],'workforce_source':wf,'source_qualifier':'CONDITIONAL_FORECAST_NOT_VERIFIED_CURRENT_PAYROLL','buildings':BUILDINGS,'floors':floor_schedule,'room_geometry_ft':ALL_ROOMS,'verification':SYMBOL_COUNTS,'design_rules':['One coordinate system for campus, one fixed footprint per building.','One floor per floor-plan image.','A and B stairs and lift/service coordinates repeat on all their levels.','J2 is physically separate from ESS.','Audit has a separate secured suite in A-L03, with independent Board accountability.','Education 35 is included in J2 237; residence learners and visiting faculty are not new payroll.','48 Contact fitted workstations include Mara Hammer and the unnamed Deputy office.','JAG six teams remain five people each; 12 desks are touchdown capacity only.','20 shared/visiting places comprise 12 on A-L01 and 8 enterprise leadership/visiting allowances on A-L03; exact named-person allocation remains to be reconciled.','Shared campus kitchen in C; dining commons in A and C each 80 seats.','Colocation and established Fort/Bedford/industrial operations are not relocated to Sacramento.']}
    (HERE/'campus_model.json').write_text(json.dumps(model,indent=2)+'\n')
    table='\n'.join(f'| {r["id"]} | {r["gross_sf"]:,} | {r["desks"]} | {r.get("rooms",0)} | {r["purpose"]} | {r["drawing_status"]} |' for r in floor_schedule)
    (HERE/'DESIGN_BASIS_AND_DECISION.md').write_text(f'''# Sacramento campus — coordinated draft R01

The owner approved Sacramento as the primary operating base and all discussed Sacramento functions on one campus on September 11, 2026. This accepts the common-campus and co-sited Education direction (the recovered D-01 and Education co-siting component of D-02). It does not approve the previous square-footage/desk/room estimates or this drawing style. This is a review package; no repository push has occurred.

The scope is corporate, Foundry Field, Atlas Meridian, Advisory, J2 and Education/residence. Established Fort, Bedford, Wyoming industrial sites, field hosts and professional colocation retain their separate locations. This interpretation follows the user's express Sacramento HQ deliverable and existing accepted geography.

## Source basis

Current GitHub main was checked at `{BASE}`. See campus_model.json for exact source paths, SHA-256 hashes, populations and all geometry. Source workforce values are conditional forecast inputs, not a verified current payroll. No unsupported department headcounts are invented. The draft uses the source 284 corporate/product/Advisory population and 180 J2 scenario occupants; the latter includes Education. 237 J2 billets are separately established canon. The remaining Core populations and industrial staffing stay at their existing operating sites.

## One campus, ten coordinated floors

| Floor | Gross sq ft | Fitted workstations | Residential rooms | Program | Drawing status |
|---|---:|---:|---:|---|---|
{table}

Total: 175,392 GSF; 362 fitted staff workplaces; 60 bedrooms. The recovered gross envelope was 173,750 GSF. The 1,642 GSF increase (0.95%) regularizes floorplates. Net usable area is not yet validated; wall/shaft and structural thicknesses must be measured in the detailed model rather than applying a blanket efficiency as fact. Floor boundary dimensions are planning dimensions.

Building A is 216 × 108 ft, three floors. B is 216 × 104 ft, two floors. C is 168 × 90 ft, two floors. D is 168 × 60 ft, three floors. Footprints on the campus map match the floor drawings. Repeated lift, stair and service shafts are reserved for all levels. Remaining seven floor drawings are intentionally held for style approval; their program reservations are already coordinated here.

## Population and use discipline

Foundry Field 160 modeled occupants / 80 desks; Atlas 36 / 32; Advisory 32 / 20; ESS 48 / 40; Audit 8 / 8. Twenty shared/visiting allowances are distributed between A-L01 and A-L03. Exact executive/support person-to-position reconciliation must be completed before A-L03 is finalized; the 8 leadership/visiting places neither assert eight new hires nor place executives under ESS authority.

J2 B contains 130 desks: Contact 48; JAG 12; Judgment 30; Orientation 16; HQ 24 (2 reception + 22 above). Education's 32 desks are in C. These are proposed physical allocations, not actual occupied J2 arm populations. Source authorization stays Contact 78, Judgment 42, Orientation 24, JAG 30, HQ 28, Education 35. Contact's 48 desks include its two office desks, so named leaders are not double counted. JAG touchdown desks do not change the six five-person teams.

C-L01 contains 120 hall seats, 48 classroom seats and 80 dining seats. Those are functional room capacities, not added employees. The old 120-day-learner planning cap remains an operational booking limit; hall/classroom peaks cannot be added to it as separate populations. Two 24-person residential cohorts plus 12 faculty/visitor rooms use D's 60 bedrooms. C-L02 case and simulation spaces are reserved, not drawn yet.

One production kitchen in C serves Education and the corporate commons. Each dining commons has 80 seats (160 total), with service turns and catered event arrangements to be sized against the attendance scenario. No production data center is inserted into the office campus; local IT rooms support buildings only.

## What these drafts establish

A common north orientation, consistent line weights, room names tied to functions, readable workstation symbols, physical dimensions, shared circulation, separate access regimes and a coordinated floor schedule. This is an architectural concept study, not a certified building design or evidence of a selected property. The campus uses a fictional 840 × 600 ft (11.57-acre) study rectangle. Parking bay counts precede accessible-bay conversion and do not assert transport sufficiency. Civil, accessibility, fire/life-safety, utilities, structural and property conditions are future design gates.

## Remaining before the complete drawing set

Approve or revise this drawing style; reconcile precise departmental staffing/attendance and executive offices; develop detailed upper-floor and residential room schedules; resolve core access, service routes, door/fixture clearances and accessible layouts; size dining, parking and event peaks together; and record the approved direction and final generated sources in the repository. The final repo package should include geometry, generator, room/workstation schedules, validation, source lineage, one image per floor and the campus master plan.
''')
    (HERE/'VALIDATION.json').write_text(json.dumps({'source_main':BASE,'checks':{'drawn_room_bounds':'PASS','drawn_room_nonoverlap':'PASS','A_L02_workstations':112,'B_L01_workstations':62,'C_L01_workstations':4,'C_L01_teaching_seats':168,'C_L01_dining_seats':80,'all_floors_workplaces':362,'campus_footprint_to_floor_consistency':'PASS','gross_total_sf':175392},'not_certified':['code compliance','accessible fixtures and door clearances','building engineering','approved actual payroll','real parcel fit','parking sufficiency'],'sheet_details':SYMBOL_COUNTS},indent=2)+'\n')
    zpath=HERE/'SABLE_HARBOR_Sacramento_HQ_Drafts_R01.zip'
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(HERE.iterdir()):
            if p.suffix in ['.py','.json','.md']:z.write(p,p.name)
        for p in sorted(OUT.iterdir()):z.write(p,'drawings/'+p.name)
    print(json.dumps({'sheets':SHEETS,'archive':str(zpath),'validation':SYMBOL_COUNTS},indent=2))

if __name__=='__main__':
    corporate();j2();education();campus();docs()
